//
//  JZPlayerController.swift
//  JZAVPlayerController
//
//  Created by Jun Zhang on 16/7/26.
//  Copyright © 2016年 Jun Zhang. All rights reserved.
//

//import UIKit
//import AVKit
//import AVFoundation
